// Moible Menu
console.clear();

const hamIcon = document.getElementById('ham');
const body = document.body;

hamIcon.addEventListener('click', () => {
    body.classList.toggle('nav-is-toggled');
    const isOpen = body.classList.contains('nav-is-toggled');
    hamIcon.innerHTML = isOpen ? `<i class="fas fa-times"></i>` : `<i class="fa-solid fa-bars"></i>`;
});